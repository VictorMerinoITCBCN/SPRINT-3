package cat.iticbcn.clientiot;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AccesMethodsToDB {

    // Método para seleccionar alumnos
    public void selectAlumnes(Connection conexion) {
        String consulta = "SELECT id, name, lastName, email FROM User";

        try (PreparedStatement statement = conexion.prepareStatement(consulta);
             ResultSet resultado = statement.executeQuery()) {

            while (resultado.next()) {
                int id = resultado.getInt("id");
                String nombre = resultado.getString("name");
                String apellido = resultado.getString("lastName");
                String correo = resultado.getString("email");

                System.out.println("ID: " + id + ", Nombre: " + nombre + ", Apellido: " + apellido + ", Email: " + correo);
            }

        } catch (SQLException excepcionSQL) {
            excepcionSQL.printStackTrace();
        }
    }

    // Método para insertar registros de asistencia
    public boolean insertRegistry(Connection conexion, String tarjetaID, int idAsignatura) {
        String consultaSelect = "SELECT id FROM User WHERE cardID = ?";
        String consultaInsert = "INSERT INTO Assistance (studentID, subjectID, attendance_status, date) VALUES (?, ?, ?, NOW())";

        try (PreparedStatement statementSelect = conexion.prepareStatement(consultaSelect);
             PreparedStatement statementInsert = conexion.prepareStatement(consultaInsert)) {

            // Buscar el estudiante por su tarjeta
            statementSelect.setString(1, tarjetaID);
            try (ResultSet resultado = statementSelect.executeQuery()) {
                if (resultado.next()) {
                    int idEstudiante = resultado.getInt("id");

                    // Insertar asistencia
                    statementInsert.setInt(1, idEstudiante);
                    statementInsert.setInt(2, idAsignatura);
                    statementInsert.setString(3, "present");

                    return statementInsert.executeUpdate() > 0;
                }
            }
        } catch (SQLException excepcionSQL) {
            excepcionSQL.printStackTrace();
        }
        return false; // En caso de error o si no se encuentra el usuario
    }
}
