package cat.iticbcn.clientiot;

import java.sql.Connection;

public class ClientIoT {

    static final String urlBD = "jdbc:mysql://192.168.22.1:3306/gestion_academica";
    static final String usuarioBD = "Dani";
    static final String contrasenaBD = "12345";

    public static void main(String[] args) {
        try (Connection conexion = ConnectDB.getConnection(urlBD, usuarioBD, contrasenaBD)) {
            DispositiuIot.initClient();
            DispositiuIot.conecta();

            TopicIoT topic = new TopicIoT(DispositiuIot.TOPIC, DispositiuIot.TOPIC_QOS, conexion);
            DispositiuIot.awsIotClient.subscribe(topic, true);

            while (true) {
                Thread.sleep(1000); // Mantener activo para recibir mensajes
            }
        } catch (Exception excepcion) {
            excepcion.printStackTrace();
        }
    }
}
