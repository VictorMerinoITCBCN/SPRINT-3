package cat.iticbcn.clientiot;

import com.amazonaws.services.iot.client.AWSIotException;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import com.amazonaws.services.iot.client.AWSIotQos;
import com.amazonaws.services.iot.client.sample.sampleUtil.SampleUtil;
import com.amazonaws.services.iot.client.sample.sampleUtil.SampleUtil.KeyStorePasswordPair;

public class DispositiuIot {

    private static final String FICH_CLAU_PRIVADA = "9b901d7ec372b17654ee70609154b3026f3ec07b7cf84f2136ff50bfd9f677a9-private.pem.key";
    private static final String FICH_CERT_DISP_IOT = "9b901d7ec372b17654ee70609154b3026f3ec07b7cf84f2136ff50bfd9f677a9-certificate.pem.crt";
    private static final String ENDPOINT = "a3roljnie6nqgm-ats.iot.eu-west-3.amazonaws.com";
    public static final String TOPIC = "iticbcn/esp32/sub";
    public static final String RESPONSE_TOPIC = "iticbcn/response";
    public static final String CLIENT_ID = "AWSPROJ";
    public static final AWSIotQos TOPIC_QOS = AWSIotQos.QOS0;

    public static AWSIotMqttClient awsIotClient;

    public static void initClient() {
        if (awsIotClient == null) {
            KeyStorePasswordPair pair = SampleUtil.getKeyStorePasswordPair(FICH_CERT_DISP_IOT, FICH_CLAU_PRIVADA, null);

            if (pair == null) {
                throw new IllegalArgumentException("Error al cargar el certificado.");
            }
            awsIotClient = new AWSIotMqttClient(ENDPOINT, CLIENT_ID, pair.keyStore, pair.keyPassword);
        }
    }

    public static void conecta() throws AWSIotException {
        initClient();
        awsIotClient.connect();
    }
}
