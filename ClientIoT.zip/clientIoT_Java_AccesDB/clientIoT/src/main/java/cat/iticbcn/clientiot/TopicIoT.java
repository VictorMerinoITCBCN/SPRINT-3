package cat.iticbcn.clientiot;

import com.amazonaws.services.iot.client.AWSIotMessage;
import com.amazonaws.services.iot.client.AWSIotQos;
import com.amazonaws.services.iot.client.AWSIotTopic;

import java.sql.Connection;

public class TopicIoT extends AWSIotTopic {

    private final Connection conexionBD;

    public TopicIoT(String topic, AWSIotQos qos, Connection conexionBD) {
        super(topic, qos);
        this.conexionBD = conexionBD;
    }

    @Override
    public void onMessage(AWSIotMessage mensaje) {
        String idTarjeta = mensaje.getStringPayload();
        System.out.println("Mensaje recibido: " + idTarjeta);

        try {
            // Acceso a la base de datos para insertar asistencia
            AccesMethodsToDB accesoBD = new AccesMethodsToDB();
            boolean registroExitoso = accesoBD.insertRegistry(conexionBD, idTarjeta, 1); // ID de asignatura predeterminado

            // Construir y enviar la respuesta
            String respuesta = registroExitoso ? "Registro insertado correctamente" : "Error al insertar el registro";
            enviarRespuesta(respuesta);

        } catch (Exception excepcion) {
            excepcion.printStackTrace();
            enviarRespuesta("Error: " + excepcion.getMessage());
        }
    }

    private void enviarRespuesta(String mensaje) {
        AWSIotMessage respuesta = new AWSIotMessage(DispositiuIot.RESPONSE_TOPIC, AWSIotQos.QOS0, mensaje);
        try {
            DispositiuIot.awsIotClient.publish(respuesta);
            System.out.println("Respuesta publicada: " + mensaje);
        } catch (Exception excepcion) {
            excepcion.printStackTrace();
        }
    }
}
