package cat.iticbcn.clientiot;

import java.sql.*;

public class ConnectDB {

    public static Connection getConnection(String urlConexion, String usuario, String contrasena) throws SQLException {
        try {
            // Establecer la conexión
            return DriverManager.getConnection(urlConexion, usuario, contrasena);
        } catch (SQLException excepcionSQL) {
            // Si ocurre un error, se lanza la excepción
            throw new SQLException("Error al establecer la conexión a la base de datos", excepcionSQL);
        }
    }
}
